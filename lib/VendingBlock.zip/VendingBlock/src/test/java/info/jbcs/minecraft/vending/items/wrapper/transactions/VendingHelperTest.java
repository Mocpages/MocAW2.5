package info.jbcs.minecraft.vending.items.wrapper.transactions;

public class VendingHelperTest {
    //ShouldNotVendIfThereIsNotEnoughSpaceToStoreItems
    //ShouldNotVendIfThereIsNotEnoughSpaceToStoreItemsInPlayerInventory
}
